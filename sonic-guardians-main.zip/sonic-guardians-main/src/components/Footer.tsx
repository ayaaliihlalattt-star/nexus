export function Footer() {
  return (
    <footer className="relative border-t border-border/40 px-6 py-16">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-10 md:grid-cols-[2fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <span className="block h-3 w-3 rounded-full bg-[var(--neon)] shadow-[0_0_12px_var(--neon)]" />
              <span className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">HiddenNoise.io</span>
            </div>
            <h3 className="mt-4 text-2xl font-bold md:text-3xl">
              Silence is a <span className="neon-text">human right.</span>
            </h3>
            <p className="mt-3 max-w-md text-sm text-muted-foreground">
              An interactive environmental awareness platform fighting the most underestimated
              pollutant of our century.
            </p>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">Mission</div>
            <ul className="mt-3 space-y-2 text-sm">
              <li>Measure</li><li>Educate</li><li>Mobilize</li><li>Reduce by 50% by 2035</li>
            </ul>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">Sources</div>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li>WHO Environmental Noise Guidelines</li>
              <li>NIH Cognitive Studies</li>
              <li>NIOSH Hearing Limits</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 flex flex-col items-center justify-center gap-2 border-t border-border/30 pt-6 text-center text-[11px] uppercase tracking-widest text-muted-foreground">
          <div className="neon-text font-mono text-sm">Sonic Guardians-Nexus-2026</div>
          <div>صنع لحل مشكلة نادرة</div>
        </div>
      </div>
    </footer>
  );
}
