import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useEffect, useRef } from "react";
import heroCity from "@/assets/hero-city.jpg";
import { Particles } from "./Particles";

export function Hero({ onStart }: { onStart: () => void }) {
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const sx = useSpring(mx, { stiffness: 60, damping: 18 });
  const sy = useSpring(my, { stiffness: 60, damping: 18 });
  const tx = useTransform(sx, [0, 1], [-20, 20]);
  const ty = useTransform(sy, [0, 1], [-20, 20]);
  const rot = useTransform(sx, [0, 1], [-2, 2]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const r = containerRef.current?.getBoundingClientRect();
      if (!r) return;
      mx.set((e.clientX - r.left) / r.width);
      my.set((e.clientY - r.top) / r.height);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [mx, my]);

  return (
    <section
      ref={containerRef}
      className="scanline relative flex min-h-screen items-center justify-center overflow-hidden"
    >
      {/* Cinematic background */}
      <motion.div
        style={{ x: tx, y: ty, scale: 1.08 }}
        className="absolute inset-0"
      >
        <img
          src={heroCity}
          alt="Cyberpunk city at night"
          className="h-full w-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/50 to-background" />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
      </motion.div>

      <div className="grid-bg absolute inset-0" />
      <Particles count={50} />

      {/* Animated sound waves */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className="animate-pulse-ring absolute -translate-x-1/2 -translate-y-1/2 rounded-full border"
            style={{
              width: 200,
              height: 200,
              borderColor: "var(--neon)",
              animationDelay: `${i * 0.6}s`,
              opacity: 0.4,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <motion.div
        style={{ rotateZ: rot }}
        className="relative z-10 mx-auto max-w-5xl px-6 text-center"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6 inline-flex items-center gap-3 rounded-full border border-border/60 bg-card/40 px-4 py-1.5 text-xs uppercase tracking-[0.3em] text-muted-foreground backdrop-blur"
        >
          <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-[var(--neon)] shadow-[0_0_12px_var(--neon)]" />
          Environmental Awareness · 2026
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.9 }}
          className="font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl lg:text-8xl"
        >
          <span className="block text-foreground">Noise Is Not Just Sound.</span>
          <span className="neon-text block">It's Invisible Pollution.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          dir="rtl"
          className="mt-4 font-mono text-lg text-muted-foreground md:text-xl"
        >
          الـتلوث الضوضائي الخفي — تهديد بيئي صامت
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="mx-auto mt-8 max-w-2xl text-balance text-base leading-relaxed text-muted-foreground md:text-lg"
        >
          Every second, hidden frequencies dismantle your focus, fracture your sleep,
          and silently elevate stress hormones. You can't see it. Your brain feels it.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <button
            onClick={onStart}
            className="group relative overflow-hidden rounded-full px-8 py-4 text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-transform hover:scale-105"
            style={{ background: "var(--gradient-neon)", boxShadow: "var(--shadow-neon)" }}
          >
            <span className="relative z-10">▶  Start Measuring Noise</span>
            <span className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-700 group-hover:translate-x-full" />
          </button>
          <a
            href="#story"
            className="rounded-full border border-border/60 bg-card/40 px-8 py-4 text-sm font-semibold uppercase tracking-widest text-foreground backdrop-blur transition hover:border-[var(--neon)] hover:text-[var(--neon)]"
          >
            Explore the Threat
          </a>
        </motion.div>

        {/* Live ticker */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="mx-auto mt-16 grid max-w-3xl grid-cols-3 gap-px overflow-hidden rounded-2xl border border-border/40 bg-border/40 text-left"
        >
          {[
            { v: "1.6B", l: "people exposed daily" },
            { v: "−35%", l: "concentration loss" },
            { v: "+62%", l: "sleep disruption" },
          ].map((s) => (
            <div key={s.l} className="bg-card/60 px-5 py-4 backdrop-blur">
              <div className="font-mono text-2xl font-bold text-[var(--neon)] md:text-3xl">{s.v}</div>
              <div className="mt-1 text-[11px] uppercase tracking-widest text-muted-foreground">{s.l}</div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[10px] uppercase tracking-[0.4em] text-muted-foreground">
        <div className="mx-auto mb-2 h-10 w-px animate-pulse bg-gradient-to-b from-transparent via-[var(--neon)] to-transparent" />
        Scroll
      </div>
    </section>
  );
}
