import { motion } from "framer-motion";
import { useEffect, useState } from "react";

type Pin = { id: number; x: number; y: number; db: number; place: string; note: string };

const SEED: Pin[] = [
  { id: 1, x: 22, y: 38, db: 92, place: "Manhattan, NY", note: "Construction + sirens 24/7" },
  { id: 2, x: 50, y: 32, db: 78, place: "London, UK", note: "Underground vibration" },
  { id: 3, x: 56, y: 36, db: 88, place: "Cairo, EG", note: "Continuous traffic horns" },
  { id: 4, x: 78, y: 44, db: 95, place: "Mumbai, IN", note: "Festival fireworks" },
  { id: 5, x: 84, y: 38, db: 82, place: "Tokyo, JP", note: "Pachinko district" },
  { id: 6, x: 60, y: 30, db: 70, place: "Berlin, DE", note: "Tram station near home" },
  { id: 7, x: 28, y: 64, db: 86, place: "São Paulo, BR", note: "Highway corridor" },
  { id: 8, x: 88, y: 60, db: 74, place: "Sydney, AU", note: "Airport flight path" },
  { id: 9, x: 54, y: 58, db: 90, place: "Lagos, NG", note: "Generators night-long" },
];

function dbColor(db: number) {
  if (db < 65) return "var(--safe)";
  if (db < 80) return "var(--warn)";
  if (db < 90) return "oklch(0.78 0.2 50)";
  return "var(--danger)";
}

export function NoiseMap() {
  const [pins, setPins] = useState<Pin[]>(SEED);
  const [active, setActive] = useState<Pin | null>(null);
  const [form, setForm] = useState({ place: "", note: "", db: 75 });

  // Simulate live activity
  useEffect(() => {
    const t = setInterval(() => {
      setPins((p) =>
        p.map((pin) => ({ ...pin, db: Math.max(40, Math.min(110, pin.db + (Math.random() - 0.5) * 6)) }))
      );
    }, 2000);
    return () => clearInterval(t);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.place.trim()) return;
    setPins((p) => [
      ...p,
      {
        id: Date.now(),
        x: 20 + Math.random() * 70,
        y: 25 + Math.random() * 55,
        db: form.db,
        place: form.place,
        note: form.note || "User report",
      },
    ]);
    setForm({ place: "", note: "", db: 75 });
  };

  return (
    <section className="relative px-6 py-32">
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 text-center">
          <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--neon)]">Global · Live</div>
          <h2 className="mt-3 text-4xl font-bold md:text-6xl">Community Noise Map</h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            A planet wired with sound. Pins update in real time as users report harmful zones.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
          <div className="glass relative aspect-[16/9] overflow-hidden rounded-3xl">
            {/* fake world grid */}
            <div className="absolute inset-0 grid-bg opacity-50" />
            <svg viewBox="0 0 100 56" className="absolute inset-0 h-full w-full">
              <defs>
                <radialGradient id="globe" cx="50%" cy="50%" r="60%">
                  <stop offset="0%" stopColor="oklch(0.82 0.18 195 / 0.15)" />
                  <stop offset="100%" stopColor="transparent" />
                </radialGradient>
              </defs>
              <ellipse cx="50" cy="28" rx="46" ry="22" fill="url(#globe)" />
              {/* lat/long lines */}
              {[10, 20, 30, 40].map((r) => (
                <ellipse key={r} cx="50" cy="28" rx={r * 1.1} ry={r * 0.55} fill="none" stroke="var(--neon)" strokeWidth="0.05" opacity="0.3" />
              ))}
              {[20, 35, 50, 65, 80].map((x) => (
                <line key={x} x1={x} y1="6" x2={x} y2="50" stroke="var(--neon)" strokeWidth="0.05" opacity="0.2" />
              ))}
            </svg>

            {/* scan line */}
            <div className="pointer-events-none absolute inset-x-0 h-px animate-scan" style={{ background: "linear-gradient(90deg, transparent, var(--neon), transparent)", boxShadow: "0 0 20px var(--neon)" }} />

            {pins.map((pin) => {
              const c = dbColor(pin.db);
              return (
                <button
                  key={pin.id}
                  onClick={() => setActive(pin)}
                  className="group absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${pin.x}%`, top: `${pin.y}%` }}
                >
                  <span className="absolute inset-0 -m-3 animate-pulse-ring rounded-full border" style={{ borderColor: c }} />
                  <span className="block h-3 w-3 rounded-full" style={{ background: c, boxShadow: `0 0 12px ${c}` }} />
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 whitespace-nowrap rounded-md border border-border/60 bg-background/90 px-2 py-0.5 text-[10px] font-mono opacity-0 backdrop-blur transition group-hover:opacity-100">
                    {pin.place} · {pin.db.toFixed(0)} dB
                  </span>
                </button>
              );
            })}
          </div>

          <div className="space-y-4">
            <form onSubmit={submit} className="glass space-y-3 rounded-2xl p-5">
              <div className="text-[11px] uppercase tracking-[0.3em] text-[var(--neon)]">Report a noisy zone</div>
              <input
                value={form.place}
                onChange={(e) => setForm({ ...form, place: e.target.value })}
                placeholder="City or location"
                className="w-full rounded-lg border border-border/60 bg-background/60 px-3 py-2 text-sm outline-none focus:border-[var(--neon)]"
              />
              <input
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
                placeholder="What's happening?"
                className="w-full rounded-lg border border-border/60 bg-background/60 px-3 py-2 text-sm outline-none focus:border-[var(--neon)]"
              />
              <div>
                <div className="mb-1 flex justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
                  <span>Decibels</span>
                  <span className="font-mono text-[var(--neon)]">{form.db} dB</span>
                </div>
                <input
                  type="range" min={40} max={110} value={form.db}
                  onChange={(e) => setForm({ ...form, db: +e.target.value })}
                  className="w-full accent-[var(--neon)]"
                />
              </div>
              <button type="submit" className="w-full rounded-lg py-2 text-xs font-bold uppercase tracking-widest text-primary-foreground" style={{ background: "var(--gradient-neon)" }}>
                + Drop pin
              </button>
            </form>

            <div className="glass rounded-2xl p-5">
              <div className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">Selected zone</div>
              {active ? (
                <div className="mt-2">
                  <div className="text-lg font-bold">{active.place}</div>
                  <div className="font-mono text-2xl" style={{ color: dbColor(active.db) }}>{active.db.toFixed(0)} dB</div>
                  <div className="mt-1 text-sm text-muted-foreground">{active.note}</div>
                </div>
              ) : (
                <div className="mt-2 text-sm text-muted-foreground">Tap a glowing pin to inspect.</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
