import { motion } from "framer-motion";

function Radial({ value, label, color }: { value: number; label: string; color: string }) {
  const r = 42;
  const c = 2 * Math.PI * r;
  return (
    <div className="glass flex flex-col items-center gap-3 rounded-2xl p-6">
      <div className="relative h-32 w-32">
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
          <circle cx="50" cy="50" r={r} fill="none" stroke="var(--border)" strokeWidth="6" />
          <motion.circle
            cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="6"
            strokeLinecap="round" strokeDasharray={c}
            initial={{ strokeDashoffset: c }}
            whileInView={{ strokeDashoffset: c * (1 - value / 100) }}
            transition={{ duration: 1.4, ease: "easeOut" }}
            viewport={{ once: true }}
            style={{ filter: `drop-shadow(0 0 8px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-mono text-2xl font-bold" style={{ color }}>
          {value}%
        </div>
      </div>
      <div className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">{label}</div>
    </div>
  );
}

export function AIAnalysis({ db }: { db: number }) {
  const intensity = Math.max(0, Math.min(1, (db - 35) / 70));
  const stress = Math.round(20 + intensity * 70);
  const sleep = Math.round(15 + intensity * 75);
  const productivity = Math.round(intensity * 80);
  const fatigue = Math.round(10 + intensity * 80);

  return (
    <section className="relative px-6 py-32">
      <div className="mx-auto max-w-6xl">
        <div className="mb-12 flex flex-wrap items-end justify-between gap-6">
          <div>
            <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--accent)]">AI · Cognitive Impact</div>
            <h2 className="mt-3 text-4xl font-bold md:text-6xl">
              Your Brain Under <span className="neon-text">Acoustic Load</span>
            </h2>
            <p className="mt-4 max-w-2xl text-muted-foreground">
              Our environmental assistant cross-references your live decibel exposure with WHO,
              NIH, and NIOSH datasets to estimate the cognitive cost of your current environment.
            </p>
          </div>
          <div className="font-mono text-xs text-muted-foreground">
            Analyzing <span className="text-[var(--neon)]">{db.toFixed(0)} dB</span> · model v3.2
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <Radial value={stress} label="Stress Impact" color="var(--danger)" />
          <Radial value={sleep} label="Sleep Disruption" color="oklch(0.78 0.2 50)" />
          <Radial value={productivity} label="Productivity Loss" color="var(--accent)" />
          <Radial value={fatigue} label="Mental Fatigue" color="var(--neon)" />
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {[
            { t: "Cortisol Rise", v: `+${Math.round(intensity * 40)}%`, d: "Stress hormone elevation under sustained exposure." },
            { t: "REM Sleep Loss", v: `${Math.round(intensity * 22)} min`, d: "Estimated nightly REM cycle disruption." },
            { t: "Recovery Window", v: `${Math.round(15 + intensity * 90)} min`, d: "Time needed in silence to restore baseline focus." },
          ].map((c, i) => (
            <motion.div
              key={c.t}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass relative overflow-hidden rounded-2xl p-6"
            >
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{c.t}</div>
              <div className="mt-2 font-mono text-3xl font-bold text-[var(--neon)]">{c.v}</div>
              <p className="mt-2 text-sm text-muted-foreground">{c.d}</p>
              <div className="absolute right-3 top-3 h-2 w-2 animate-pulse rounded-full bg-[var(--neon)] shadow-[0_0_10px_var(--neon)]" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
