import { motion, AnimatePresence } from "framer-motion";
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";

export type NoiseMeterHandle = { start: () => Promise<void> };

type Level = { name: string; color: string; risk: string; emotion: string; action: string };
function classify(db: number): Level {
  if (db < 55) return { name: "Safe", color: "var(--safe)", risk: "Low", emotion: "Calm · Focused", action: "Optimal for deep work and rest." };
  if (db < 70) return { name: "Uncomfortable", color: "var(--warn)", risk: "Moderate", emotion: "Distracted · Restless", action: "Concentration may drop ~15%." };
  if (db < 85) return { name: "Harmful", color: "oklch(0.78 0.2 50)", risk: "High", emotion: "Stressed · Anxious", action: "Cortisol rising. Limit exposure." };
  return { name: "Dangerous", color: "var(--danger)", risk: "Critical", emotion: "Overwhelmed · Fatigued", action: "Hearing damage risk after 8 minutes." };
}

export const NoiseMeter = forwardRef<NoiseMeterHandle, { onUpdate?: (db: number) => void }>(
  function NoiseMeter({ onUpdate }, ref) {
    const [db, setDb] = useState(0);
    const [active, setActive] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [bars, setBars] = useState<number[]>(Array(48).fill(0));
    const audioCtxRef = useRef<AudioContext | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const rafRef = useRef<number | null>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const start = async () => {
      setError(null);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        const Ctx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new Ctx();
        audioCtxRef.current = ctx;
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 1024;
        analyser.smoothingTimeConstant = 0.85;
        src.connect(analyser);
        analyserRef.current = analyser;
        setActive(true);
        loop();
      } catch (e: any) {
        setError(e?.message ?? "Microphone access denied. Use the simulation below.");
      }
    };

    useImperativeHandle(ref, () => ({ start }));

    const loop = () => {
      const analyser = analyserRef.current;
      if (!analyser) return;
      const buf = new Uint8Array(analyser.frequencyBinCount);
      const time = new Uint8Array(analyser.fftSize);
      analyser.getByteFrequencyData(buf);
      analyser.getByteTimeDomainData(time);

      // RMS -> approximate dB SPL (calibrated rough)
      let sum = 0;
      for (let i = 0; i < time.length; i++) {
        const v = (time[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / time.length);
      const dbfs = 20 * Math.log10(rms || 0.0001);
      const approx = Math.max(28, Math.min(120, 94 + dbfs)); // heuristic SPL
      setDb((prev) => prev * 0.7 + approx * 0.3);

      // bars
      const n = 48;
      const step = Math.floor(buf.length / n);
      const next: number[] = [];
      for (let i = 0; i < n; i++) next.push(buf[i * step] / 255);
      setBars(next);

      rafRef.current = requestAnimationFrame(loop);
    };

    useEffect(() => {
      onUpdate?.(db);
    }, [db, onUpdate]);

    useEffect(() => {
      return () => {
        rafRef.current && cancelAnimationFrame(rafRef.current);
        streamRef.current?.getTracks().forEach((t) => t.stop());
        audioCtxRef.current?.close().catch(() => {});
      };
    }, []);

    const level = classify(db);
    const pct = Math.min(1, Math.max(0, (db - 30) / 90));
    const focusLoss = Math.round(Math.max(0, (db - 45) * 0.85));

    return (
      <div className="glass relative overflow-hidden rounded-3xl p-8 md:p-12">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--neon)]">Live · HUD</div>
            <h3 className="mt-2 text-3xl font-bold md:text-5xl">Real-Time Noise Meter</h3>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">
              Powered by your microphone via the Web Audio API. Approximate SPL — for awareness,
              not laboratory measurement.
            </p>
          </div>
          {!active ? (
            <button
              onClick={start}
              className="rounded-full px-6 py-3 text-xs font-bold uppercase tracking-widest text-primary-foreground transition hover:scale-105"
              style={{ background: "var(--gradient-neon)", boxShadow: "var(--shadow-neon)" }}
            >
              ◉ Activate Microphone
            </button>
          ) : (
            <div className="flex items-center gap-2 rounded-full border border-border/60 bg-card/60 px-4 py-2 text-xs">
              <span className="h-2 w-2 animate-pulse rounded-full bg-[var(--danger)]" />
              <span className="font-mono uppercase tracking-widest">Recording</span>
            </div>
          )}
        </div>

        {error && (
          <div className="mb-6 rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive-foreground">
            {error}
          </div>
        )}

        <div className="grid gap-8 lg:grid-cols-[auto_1fr]">
          {/* Circular meter */}
          <div className="relative mx-auto h-72 w-72 md:h-80 md:w-80">
            <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90">
              <circle cx="100" cy="100" r="86" fill="none" stroke="var(--border)" strokeWidth="6" />
              <circle
                cx="100" cy="100" r="86" fill="none"
                stroke={level.color}
                strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 86}`}
                strokeDashoffset={`${2 * Math.PI * 86 * (1 - pct)}`}
                style={{
                  transition: "stroke-dashoffset 0.3s ease, stroke 0.6s",
                  filter: `drop-shadow(0 0 12px ${level.color})`,
                }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">Decibels</div>
              <div className="font-mono text-6xl font-bold tabular-nums" style={{ color: level.color, textShadow: `0 0 20px ${level.color}` }}>
                {db.toFixed(0)}
              </div>
              <div className="text-xs text-muted-foreground">dB SPL</div>
              <div className="mt-2 rounded-full border px-3 py-0.5 text-[11px] font-semibold uppercase tracking-widest"
                style={{ borderColor: level.color, color: level.color }}>
                {level.name}
              </div>
            </div>
          </div>

          {/* Frequency bars + readouts */}
          <div className="flex flex-col gap-6">
            <div className="flex h-40 items-end gap-1 rounded-2xl border border-border/40 bg-background/40 p-4">
              {bars.map((v, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-t"
                  style={{
                    height: `${Math.max(4, v * 100)}%`,
                    background: `linear-gradient(to top, ${level.color}, transparent)`,
                    boxShadow: `0 0 8px ${level.color}`,
                    transition: "height 80ms linear",
                  }}
                />
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
              <Stat label="Health Risk" value={level.risk} color={level.color} />
              <Stat label="Emotional State" value={level.emotion} />
              <Stat label="Focus Loss" value={`-${focusLoss}%`} color={level.color} />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={level.name}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="rounded-2xl border p-4"
                style={{ borderColor: level.color, background: `${level.color.replace(")", " / 0.08)")}` }}
              >
                <div className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">AI Recommendation</div>
                <div className="mt-1 text-sm">{level.action}</div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        <div
          className="pointer-events-none absolute -inset-px rounded-3xl opacity-60"
          style={{ background: `radial-gradient(600px circle at 50% 0%, ${level.color}, transparent 60%)`, mixBlendMode: "overlay" }}
        />
      </div>
    );
  }
);

function Stat({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="rounded-xl border border-border/40 bg-card/60 p-3">
      <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">{label}</div>
      <div className="mt-1 font-mono text-lg font-bold" style={{ color: color ?? "var(--foreground)" }}>{value}</div>
    </div>
  );
}
