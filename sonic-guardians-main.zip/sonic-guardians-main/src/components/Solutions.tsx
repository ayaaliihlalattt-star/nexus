import { motion } from "framer-motion";
import { Headphones, Trees, Building2, Volume2, Moon, Megaphone, Scale, GraduationCap } from "lucide-react";

const PERSONAL = [
  { icon: Headphones, t: "Active Noise Cancellation", ar: "سماعات عازلة للضوضاء", d: "Use ANC headphones or foam earplugs (NRR 25+) in transit and open offices.", ard: "استخدم سماعات ANC أو سدادات أذن رغوية في المواصلات والمكاتب المفتوحة." },
  { icon: Moon, t: "Protect Your Sleep", ar: "احمِ نومك", d: "White-noise machines, heavy curtains, and silent mode after 10 PM rebuild REM cycles.", ard: "أجهزة الضوضاء البيضاء والستائر الثقيلة ووضع الصمت بعد العاشرة تعيد بناء دورات النوم." },
  { icon: Volume2, t: "Follow the 60/60 Rule", ar: "قاعدة 60/60", d: "Never exceed 60% volume for more than 60 minutes. Give your cochlea recovery time.", ard: "لا تتجاوز 60% من الصوت لأكثر من 60 دقيقة. امنح أذنك وقتاً للتعافي." },
  { icon: Trees, t: "Seek Silence Daily", ar: "ابحث عن الصمت يومياً", d: "20 minutes in nature or a quiet room lowers cortisol and restores attention span.", ard: "20 دقيقة في الطبيعة أو غرفة هادئة تخفض الكورتيزول وتستعيد التركيز." },
];

const COLLECTIVE = [
  { icon: Building2, t: "Acoustic Architecture", ar: "العمارة الصوتية", d: "Green walls, double-glazed windows, and sound-absorbing materials cut indoor noise by 40%.", ard: "الجدران الخضراء والنوافذ المزدوجة والمواد الماصة تقلل الضوضاء الداخلية بنسبة 40%." },
  { icon: Trees, t: "Urban Sound Barriers", ar: "حواجز صوتية حضرية", d: "Tree corridors and noise berms along highways reduce traffic noise by up to 15 dB.", ard: "ممرات الأشجار والحواجز على الطرق السريعة تخفض ضجيج السير حتى 15 ديسيبل." },
  { icon: Scale, t: "Stronger Regulation", ar: "تشريعات أقوى", d: "Enforce WHO night limits (40 dB) and ban unnecessary horn use in residential zones.", ard: "تطبيق حدود منظمة الصحة العالمية الليلية (40 ديسيبل) وحظر استخدام الأبواق في المناطق السكنية." },
  { icon: GraduationCap, t: "Schools of Silence", ar: "مدارس الصمت", d: "Acoustic ceilings and quiet zones improve reading scores by 27% within one semester.", ard: "الأسقف العازلة ومناطق الهدوء ترفع درجات القراءة بنسبة 27% خلال فصل واحد." },
];

function Card({ item, i, color }: { item: typeof PERSONAL[number]; i: number; color: string }) {
  const Icon = item.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: i * 0.08, duration: 0.6 }}
      whileHover={{ y: -6 }}
      className="glass group relative overflow-hidden rounded-2xl p-6"
    >
      <div
        className="absolute -right-12 -top-12 h-40 w-40 rounded-full opacity-20 blur-3xl transition-opacity group-hover:opacity-50"
        style={{ background: color }}
      />
      <div
        className="relative mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl border"
        style={{ borderColor: color, boxShadow: `0 0 20px ${color}` }}
      >
        <Icon className="h-6 w-6" style={{ color }} />
      </div>
      <div className="relative">
        <h4 className="text-xl font-bold">{item.t}</h4>
        <div dir="rtl" className="mt-1 text-sm font-semibold" style={{ color }}>{item.ar}</div>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.d}</p>
        <p dir="rtl" className="mt-2 text-sm leading-relaxed text-muted-foreground/80">{item.ard}</p>
      </div>
      <div
        className="absolute bottom-0 left-0 h-px w-full origin-left scale-x-0 transition-transform duration-500 group-hover:scale-x-100"
        style={{ background: color, boxShadow: `0 0 8px ${color}` }}
      />
    </motion.div>
  );
}

export function Solutions() {
  return (
    <section id="solutions" className="relative px-6 py-32">
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{ background: "radial-gradient(ellipse at top, oklch(0.5 0.2 180 / 0.15), transparent 60%)" }}
      />
      <div className="mx-auto max-w-6xl">
        <div className="mb-16 text-center">
          <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--neon)]">The Antidote · الحل</div>
          <h2 className="mt-3 text-4xl font-bold md:text-6xl">
            Reclaiming the <span className="neon-text">Silence</span>
          </h2>
          <p dir="rtl" className="mt-4 text-xl font-semibold text-[var(--accent)]">استعادة الصمت — معاً</p>
          <p className="mx-auto mt-5 max-w-2xl text-muted-foreground">
            Noise pollution is invisible — but reversible. Real change happens on two fronts:
            what you control today, and what we demand together tomorrow.
          </p>
        </div>

        {/* Personal */}
        <div className="mb-16">
          <div className="mb-6 flex items-center gap-3">
            <Headphones className="h-5 w-5 text-[var(--neon)]" />
            <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--neon)]">01 · Personal Defense</div>
            <div dir="rtl" className="text-sm text-muted-foreground">— دفاعك الشخصي</div>
          </div>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {PERSONAL.map((item, i) => (
              <Card key={item.t} item={item} i={i} color="var(--neon)" />
            ))}
          </div>
        </div>

        {/* Collective */}
        <div className="mb-16">
          <div className="mb-6 flex items-center gap-3">
            <Megaphone className="h-5 w-5 text-[var(--accent)]" />
            <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--accent)]">02 · Collective Action</div>
            <div dir="rtl" className="text-sm text-muted-foreground">— العمل الجماعي</div>
          </div>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {COLLECTIVE.map((item, i) => (
              <Card key={item.t} item={item} i={i} color="var(--accent)" />
            ))}
          </div>
        </div>

        {/* Pledge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="glass relative overflow-hidden rounded-3xl p-10 text-center md:p-14"
        >
          <div
            className="absolute inset-0 opacity-30"
            style={{ background: "var(--gradient-neon)", mixBlendMode: "overlay" }}
          />
          <div className="relative">
            <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--neon)]">The Quiet Pledge</div>
            <h3 className="mt-3 text-3xl font-bold md:text-5xl">
              One hour of <span className="neon-text">true silence</span> a day.
            </h3>
            <p dir="rtl" className="mt-3 text-xl font-bold text-[var(--accent)]">
              ساعة واحدة من الصمت الحقيقي يومياً
            </p>
            <p className="mx-auto mt-5 max-w-xl text-muted-foreground">
              Join thousands rebuilding their nervous systems — one silent hour at a time.
            </p>
            <button
              className="mt-8 rounded-full px-8 py-4 text-xs font-bold uppercase tracking-widest text-primary-foreground transition hover:scale-105"
              style={{ background: "var(--gradient-neon)", boxShadow: "var(--shadow-neon)" }}
            >
              ◉ Take the Pledge · خذ العهد
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
