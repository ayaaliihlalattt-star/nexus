import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";

type Phase = "idle" | "playing" | "done";

export function FocusGame() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(20);
  const [target, setTarget] = useState({ x: 50, y: 50 });
  const [intensity, setIntensity] = useState(0);
  const audioRef = useRef<{ ctx: AudioContext; osc: OscillatorNode; gain: GainNode } | null>(null);

  const start = () => {
    setScore(0);
    setTime(20);
    setIntensity(0);
    setPhase("playing");
    moveTarget();
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new Ctx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.value = 220;
      gain.gain.value = 0;
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      audioRef.current = { ctx, osc, gain };
    } catch {}
  };

  const stop = () => {
    setPhase("done");
    const a = audioRef.current;
    if (a) {
      a.gain.gain.value = 0;
      a.osc.stop();
      a.ctx.close().catch(() => {});
      audioRef.current = null;
    }
  };

  useEffect(() => {
    if (phase !== "playing") return;
    const t = setInterval(() => {
      setTime((s) => {
        if (s <= 1) { stop(); return 0; }
        return s - 1;
      });
      setIntensity((i) => Math.min(1, i + 0.06));
    }, 1000);
    return () => clearInterval(t);
  }, [phase]);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    a.gain.gain.value = intensity * 0.04; // safe-ish
    a.osc.frequency.value = 180 + intensity * 400;
  }, [intensity]);

  const moveTarget = () => setTarget({ x: 10 + Math.random() * 80, y: 10 + Math.random() * 75 });

  const hit = () => {
    setScore((s) => s + 1);
    moveTarget();
  };

  const rank = score >= 18 ? "Cognitive Sentinel" : score >= 12 ? "Focus Warrior" : score >= 6 ? "Distracted Citizen" : "Noise Casualty";
  const rankColor = score >= 12 ? "var(--safe)" : score >= 6 ? "var(--warn)" : "var(--danger)";

  return (
    <section className="relative px-6 py-32">
      <div className="mx-auto max-w-5xl">
        <div className="mb-10 text-center">
          <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--accent)]">Challenge · Simulator</div>
          <h2 className="mt-3 text-4xl font-bold md:text-6xl">Can You Survive a Noisy City?</h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Hit the glowing target as many times as you can in 20 seconds — while ambient noise grows louder.
            Your reflexes will tell the truth.
          </p>
        </div>

        <div className="glass relative h-[480px] overflow-hidden rounded-3xl">
          <div className="absolute inset-0 grid-bg opacity-50" />
          <div
            className="pointer-events-none absolute inset-0 transition-opacity duration-700"
            style={{ background: `radial-gradient(circle at 50% 50%, var(--danger), transparent 70%)`, opacity: intensity * 0.4 }}
          />

          {/* HUD */}
          <div className="absolute left-5 top-5 flex gap-3 font-mono text-xs">
            <div className="rounded-md border border-border/60 bg-background/60 px-3 py-1">
              SCORE <span className="ml-1 text-[var(--neon)]">{score}</span>
            </div>
            <div className="rounded-md border border-border/60 bg-background/60 px-3 py-1">
              TIME <span className="ml-1 text-[var(--neon)]">{time}s</span>
            </div>
            <div className="rounded-md border border-border/60 bg-background/60 px-3 py-1">
              NOISE <span className="ml-1" style={{ color: intensity > 0.6 ? "var(--danger)" : "var(--warn)" }}>{Math.round(40 + intensity * 60)} dB</span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {phase === "idle" && (
              <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                <div className="text-center text-sm text-muted-foreground">Audio simulation will play. Keep volume low.</div>
                <button onClick={start} className="rounded-full px-8 py-3 text-xs font-bold uppercase tracking-widest text-primary-foreground" style={{ background: "var(--gradient-neon)", boxShadow: "var(--shadow-neon)" }}>
                  ▶ Begin Simulation
                </button>
              </motion.div>
            )}
            {phase === "playing" && (
              <motion.button
                key={`${target.x}-${target.y}`}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0 }}
                onClick={hit}
                className="absolute h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full"
                style={{
                  left: `${target.x}%`, top: `${target.y}%`,
                  background: "var(--gradient-neon)",
                  boxShadow: "var(--shadow-neon)",
                  filter: `blur(${intensity * 1.5}px)`,
                }}
                aria-label="Target"
              />
            )}
            {phase === "done" && (
              <motion.div key="done" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                <div className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">Final result</div>
                <div className="font-mono text-7xl font-bold neon-text">{score}</div>
                <div className="text-sm text-muted-foreground">targets hit under acoustic stress</div>
                <div className="mt-2 rounded-full border px-4 py-1 text-xs font-bold uppercase tracking-widest" style={{ borderColor: rankColor, color: rankColor }}>
                  Rank · {rank}
                </div>
                <button onClick={start} className="mt-4 rounded-full border border-border/60 bg-card/60 px-6 py-2 text-xs font-bold uppercase tracking-widest hover:border-[var(--neon)] hover:text-[var(--neon)]">
                  Play again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="mt-8 grid gap-3 md:grid-cols-4">
          {[
            { v: "🥉", l: "Casualty · 0–5" },
            { v: "🎯", l: "Distracted · 6–11" },
            { v: "⚡", l: "Warrior · 12–17" },
            { v: "🛡️", l: "Sentinel · 18+" },
          ].map((b) => (
            <div key={b.l} className="glass rounded-xl p-4 text-center">
              <div className="text-3xl">{b.v}</div>
              <div className="mt-1 text-[11px] uppercase tracking-widest text-muted-foreground">{b.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
