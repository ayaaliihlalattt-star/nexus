import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const CHAPTERS = [
  {
    n: "01",
    t: "The Brain Under Siege",
    d: "Each unwanted sound forces your prefrontal cortex into emergency triage. Decisions slow. Memory consolidation breaks. You feel tired without knowing why.",
    color: "var(--neon)",
  },
  {
    n: "02",
    t: "Sleep, Quietly Stolen",
    d: "At 45 dB, your heart rate elevates while you sleep. REM cycles fragment. Tomorrow's mood, focus, and immune response are already compromised.",
    color: "var(--accent)",
  },
  {
    n: "03",
    t: "Anxiety You Can Hear",
    d: "Chronic exposure rewires the amygdala. The world begins to feel hostile. The source isn't your mind — it's the soundscape around it.",
    color: "oklch(0.78 0.2 50)",
  },
  {
    n: "04",
    t: "Children Stop Learning",
    d: "Schools near highways score up to 30% lower in reading comprehension. Noise doesn't just disturb — it deletes information mid-thought.",
    color: "var(--neon)",
  },
  {
    n: "05",
    t: "The City That Never Recovers",
    d: "Urban dwellers face cardiovascular risk equivalent to second-hand smoke. Every car horn is a micro-injury repeated 10,000 times a year.",
    color: "var(--danger)",
  },
  {
    n: "06",
    t: "Hearing, Permanently",
    d: "85 dB for 8 hours is enough to cause irreversible cochlear damage. By age 50, 1 in 4 people will live with hearing loss they never noticed forming.",
    color: "var(--accent)",
  },
];

function Chapter({ c, i }: { c: (typeof CHAPTERS)[number]; i: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);

  return (
    <div ref={ref} className="relative flex min-h-[90vh] items-center px-6">
      <motion.div
        style={{ y, opacity }}
        className={`mx-auto grid w-full max-w-6xl gap-8 ${i % 2 ? "md:grid-cols-[2fr_3fr]" : "md:grid-cols-[3fr_2fr]"}`}
      >
        <div className={i % 2 ? "md:order-2" : ""}>
          <div className="font-mono text-7xl font-bold opacity-30 md:text-9xl" style={{ color: c.color }}>
            {c.n}
          </div>
          <div className="mt-4 h-px w-24" style={{ background: c.color, boxShadow: `0 0 12px ${c.color}` }} />
        </div>
        <div>
          <h3 className="text-3xl font-bold leading-tight md:text-5xl">{c.t}</h3>
          <p className="mt-5 text-base leading-relaxed text-muted-foreground md:text-lg">{c.d}</p>

          {/* animated waveform */}
          <div className="mt-8 flex h-16 items-end gap-1">
            {Array.from({ length: 40 }).map((_, k) => (
              <motion.div
                key={k}
                animate={{ scaleY: [0.3, 1, 0.3] }}
                transition={{ duration: 1 + (k % 5) * 0.2, repeat: Infinity, delay: k * 0.04 }}
                className="w-1 origin-bottom rounded-t"
                style={{ height: "100%", background: c.color, boxShadow: `0 0 6px ${c.color}`, opacity: 0.4 + (k % 5) * 0.12 }}
              />
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function Storytelling() {
  return (
    <section id="story" className="relative">
      <div className="sticky top-0 -z-10 h-screen">
        <div className="grid-bg absolute inset-0" />
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, oklch(0.18 0.05 250 / 0.4), transparent 70%)" }} />
      </div>
      <div className="-mt-[100vh]">
        <div className="px-6 pt-32 text-center">
          <div className="text-[11px] uppercase tracking-[0.4em] text-[var(--accent)]">The Six Chapters</div>
          <h2 className="mt-3 text-4xl font-bold md:text-6xl">
            How Noise <span className="neon-text">Rewrites</span> You
          </h2>
        </div>
        {CHAPTERS.map((c, i) => <Chapter key={c.n} c={c} i={i} />)}
      </div>
    </section>
  );
}
