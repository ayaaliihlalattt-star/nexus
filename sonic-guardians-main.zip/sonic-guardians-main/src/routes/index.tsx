import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Hero } from "@/components/Hero";
import { NoiseMeter, type NoiseMeterHandle } from "@/components/NoiseMeter";
import { AIAnalysis } from "@/components/AIAnalysis";
import { NoiseMap } from "@/components/NoiseMap";
import { Storytelling } from "@/components/Storytelling";
import { FocusGame } from "@/components/FocusGame";
import { Solutions } from "@/components/Solutions";
import { Footer } from "@/components/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Hidden Noise Pollution — Invisible Environmental Threat" },
      { name: "description", content: "An interactive cinematic experience revealing how hidden noise destroys focus, sleep, and mental health. Live decibel meter, AI analysis, and global noise map." },
      { property: "og:title", content: "Hidden Noise Pollution" },
      { property: "og:description", content: "Noise is not just sound. It's invisible pollution." },
    ],
  }),
  component: Index,
});

function Index() {
  const meterRef = useRef<NoiseMeterHandle>(null);
  const [db, setDb] = useState(0);

  const startMeter = () => {
    document.getElementById("meter")?.scrollIntoView({ behavior: "smooth" });
    setTimeout(() => meterRef.current?.start(), 600);
  };

  return (
    <main className="relative">
      <Hero onStart={startMeter} />

      <section id="meter" className="relative px-6 py-32">
        <div className="mx-auto max-w-6xl">
          <NoiseMeter ref={meterRef} onUpdate={setDb} />
        </div>
      </section>

      <AIAnalysis db={db} />
      <Storytelling />
      <NoiseMap />
      <FocusGame />
      <Solutions />
      <Footer />
    </main>
  );
}
